from sklearn.neighbors import KNeighborsClassifier
import cv2
import pickle
import numpy as np
import os
import csv
import time
from datetime import datetime


from win32com.client import Dispatch

def speak(str1):
    speak=Dispatch(("SAPI.SpVoice"))
    speak.Speak(str1)

video=cv2.VideoCapture(0)
facedetect=cv2.CascadeClassifier('C:\\Users\\sreej\\OneDrive\\Desktop\\Face Recognition Based Attendence System\\data\\haarcascade_frontalface_default.xml')

with open('data/names.pkl', 'rb') as w:
    LABELS=pickle.load(w)
with open('data/faces_data.pkl', 'rb') as f:
    FACES=pickle.load(f)

print('Shape of Faces matrix --> ', FACES.shape)

knn=KNeighborsClassifier(n_neighbors=5)
if len(FACES) != len(LABELS):
    print("Inconsistent number of samples. Adding random labels.")
    
    # Determine how many samples need to be added
    num_samples_to_add = len(FACES) - len(LABELS)

    if num_samples_to_add>0:

        # Randomly add class labels (adjust this as needed)
        for _ in range(num_samples_to_add):
            random_class = random.choice(LABELS)
            LABELS.append(random_class)
    else:
        LABELS = LABELS[:len(FACES)]
    print("Samples adjusted to match.")
knn.fit(FACES, LABELS)

imgBackground=cv2.imread("C:\\Users\\sreej\\OneDrive\\Desktop\\Face Recognition Based Attendence System\\bg.png")

COL_NAMES = ['NAME', 'TIME']

while True:
    ret,frame=video.read()
    gray=cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces=facedetect.detectMultiScale(gray, 1.3 ,5)
    for (x,y,w,h) in faces:
        crop_img=frame[y:y+h, x:x+w, :]
        resized_img=cv2.resize(crop_img, (50,50)).flatten().reshape(1,-1)
        output=knn.predict(resized_img)
        ts=time.time()
        date=datetime.fromtimestamp(ts).strftime("%d-%m-%Y")
        timestamp=datetime.fromtimestamp(ts).strftime("%H:%M-%S")
        exist=os.path.isfile("C:\\Users\\sreej\\OneDrive\\Desktop\\Face Recognition Based Attendence System\\Attendance\\Attendance_07-04-2023.csv" + date + ".csv")
        cv2.rectangle(frame, (x,y), (x+w, y+h), (0,0,255), 1)
        cv2.rectangle(frame,(x,y),(x+w,y+h),(50,50,255),2)
        cv2.rectangle(frame,(x,y-40),(x+w,y),(50,50,255),-1)
        cv2.putText(frame, str(output[0]), (x,y-15), cv2.FONT_HERSHEY_COMPLEX, 1, (255,255,255), 1)
        cv2.rectangle(frame, (x,y), (x+w, y+h), (50,50,255), 1)
        attendance=[str(output[0]), str(timestamp)]
    imgBackground[262:262 + 480, 155:155 + 640] = frame
    cv2.imshow("Frame",imgBackground)
    k=cv2.waitKey(1)
    if k==ord('o'):
        speak("Attendance Taken..")
        time.sleep(5)
        if exist:
            with open("C:\\Users\\sreej\\OneDrive\\Desktop\\Face Recognition Based Attendence System\\Attendance\\Attendance_07-04-2023.csv" + date + ".csv", "+a") as csvfile:
                writer=csv.writer(csvfile)
                writer.writerow(attendance)
            csvfile.close()
        else:
            with open("C:\\Users\\sreej\\OneDrive\\Desktop\\Face Recognition Based Attendence System\\Attendance\\Attendance_07-04-2023.csv" + date + ".csv", "+a") as csvfile:
                writer=csv.writer(csvfile)
                writer.writerow(COL_NAMES)
                writer.writerow(attendance)
            csvfile.close()
    if k==ord('q'):
        break
video.release()
cv2.destroyAllWindows()
