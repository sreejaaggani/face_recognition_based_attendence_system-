import streamlit as st
import pandas as pd
import time
from datetime import datetime

# Upload the background image
background_image = st.file_uploader("C:\\Users\\sreej\\OneDrive\\Desktop\\Face Recognition Based Attendence System\\bvrit.jpeg", type=["jpeg"])

# Define custom CSS for the background
if background_image is not None:
    background_css = f"""
    <style>
        body {{
            background-image: url(data:image/jpeg;base64,{background_image.read().decode()});
            background-size: cover;
        }}
    </style>
    """
    st.markdown(background_css, unsafe_allow_html=True)

ts = time.time()
date = datetime.fromtimestamp(ts).strftime("%d-%m-%Y")

from streamlit_autorefresh import st_autorefresh

count = st_autorefresh(interval=2000, limit=100, key="fizzbuzzcounter")

if count == 0:
    st.write("Count is zero")
elif count % 3 == 0 and count % 5 == 0:
    st.write("FizzBuzz")
elif count % 3 == 0:
    st.write("Fizz")
elif count % 5 == 0:
    st.write("Buzz")
else:
    st.write(f"Count: {count}")

# Assuming the CSV file name follows the format "Attendance_DD-MM-YYYY.csv"
csv_file_name = f"Attendance_{date}.csv"

try:
    df = pd.read_csv(csv_file_name)
    st.dataframe(df.style.highlight_max(axis=0))
except FileNotFoundError:
    st.write(f"Attendance data for {date} is not available.")

